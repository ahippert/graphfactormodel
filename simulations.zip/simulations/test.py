import sknetwork
print('test')
